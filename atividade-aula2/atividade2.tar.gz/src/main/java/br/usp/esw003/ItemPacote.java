package br.usp.esw003;

public class ItemPacote {

    //TODO trocar para Moneta
    private float preco = 0;

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }
}

